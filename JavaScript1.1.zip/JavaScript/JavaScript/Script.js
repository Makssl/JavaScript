﻿//Задание 1
var summ = 0;

for(var i=10; i<=20; i++) {
	summ=summ+i;
	console.log(i*i);
		
}
console.log("Сумма = " + summ);





//Задание 2
function buttonClick() {
	
	
	var x1 = parseInt(document.getElementById("x1").value);
	var x2 = parseInt(document.getElementById("x2").value);
	
	document.getElementById("result").innerHTML = "";
	document.getElementById("simpleNumbers").innerHTML = "Simple numbers: ";
	
	if(document.getElementById("x1").value == "" || document.getElementById("x2").value == "") {
		alert("Поля должны быть заполнены! ");
	} else{
	
		if(Number.isNaN(x1) || Number.isNaN(x2)) {
			alert("В поля должны быть введены числовые значения. ");
		} else {
			
			if(parseInt(document.getElementById("x1").value) > parseInt(document.getElementById("x2").value)) {
				alert("X1 должно быть меньше X2");
			} else {
				
				
			
				for(var k=x1; k<=x2; k++) {   //вывод простых чисел
					var counter = 0;
					for (var l=1; l<=k; l++) {
						if ( k % l == 0 ) {
							counter++;
						}
					}
					var simpleAll = document.getElementById("simpleNumbers");
					if (counter <= 2) {
						simpleAll.append(k + "; ");
					}
				}
				
			
				var resultDiv = document.getElementById("result");
			
				if (document.getElementById("radio1").checked) {
					var summ1 = 0;
					for(var j=x1; j<=x2; j++) {   //вычисление суммы
						summ1 = summ1+j;
					}
					resultDiv.append("Summ between x1 ("+ x1 + ") and x2 (" + x2 + ") = " + (summ1));
				} else {
					var product = 1;
					for(var j=x1; j<=x2; j++) {   //вычисление произведения
						product = product * j;
					}
					resultDiv.append("Product between x1 ("+ x1 + ") and x2 (" + x2 + ") = " + (product));
				}			
			
				document.getElementById("x1").value = null;
				document.getElementById("x2").value = null;

			}
		}
	}
	
}

function clearInput() {
	document.getElementById("x1").value = null;
	document.getElementById("x2").value = null;
}


//игра 
// не успел сделать рандомное создание расположения картинок, поэтому оно всегда одинаковое(
var Used = 0;
var IdOfFirst = "";
var IndexOfFirst = "";
var IndexOfSecond = "";
var Pattern = [["cell1","images/image1.png"],["cell2","images/image2.png"],["cell3","images/image2.png"],
				["cell4","images/image3.png"],["cell5","images/image4.png"],["cell6","images/image4.png"],
				["cell7","images/image5.png"],["cell8","images/image3.png"],["cell9","images/image5.png"],["cell10","images/image1.png"]];
var AllOfImages = ["images/image1.png", "images/image2.png", "images/image3.png", "images/image4.png", "images/image5.png"];
var UsedCells = [false,false,false,false,false,false,false,false,false,false];

function testt(IdOfThis) {
	Used++;
	if (Used==1) {
		for (var m=0; m<=9; m++) {
			if (Pattern [m] [0] == IdOfThis) {
				document.getElementById(IdOfThis).src = Pattern [m] [1];
				IndexOfFirst = m;
			}
		}
		IdOfFirst=IdOfThis;
	}
	if (Used==2) {
		for (var m=0; m<=9; m++) {
			if (Pattern [m] [0] == IdOfThis) {
				document.getElementById(IdOfThis).src = Pattern [m] [1];
				IndexOfSecond = m;
			}
		}
		
		if (Pattern [IndexOfFirst] [1] == Pattern [IndexOfSecond] [1]) {
			setTimeout(function() { document.getElementById(IdOfFirst).style.visibility = "hidden";
									document.getElementById(IdOfThis).style.visibility = "hidden";
									Used=0; } , 1000 );
	
		} else {		
			
		
			setTimeout(function() { document.getElementById(IdOfThis).src = "images/redbackground.png";
									document.getElementById(IdOfFirst).src = "images/redbackground.png";
									Used=0; } , 2000);
		}
		
	}
}


